class GroupOverflowError(Exception):
    pass